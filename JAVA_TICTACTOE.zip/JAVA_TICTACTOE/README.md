# JavaTicTacToe
A TicTacToe Game Built in Java Swing. Used Minimax Algorithm for Bot

## GAME<br>
<img src="https://github.com/adigapranava/JavaTicTacToe/blob/main/images/game3.gif?raw=true" width="400">
